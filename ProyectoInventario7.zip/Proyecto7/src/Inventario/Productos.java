package Inventario;

import java.util.Scanner;

public class Productos {
	private int ID;
	private String Nombre;
    private int Cantidad;
    private double Precio;
	private boolean Estado = true;
	


    public Productos(int ID, String Nombre, int Cantidad, double Precio, boolean Estado) {
        this.ID = ID;
        this.Nombre = Nombre;
        this.Cantidad = Cantidad;
        this.Precio = Precio;
    	this.Estado = Estado;
    }
    
    public int getID() {
        return ID;
    }

    public String getNombre() {
        return Nombre;
    }

    public int getCantidad() {
        return Cantidad;
    }

    public double getPrecio() {
        return Precio;
    }
    
    public String getEstado() {
	     	String estadoString;

	     	if (Estado) {
	     		estadoString = "Activo";
	     	} else {
	     		estadoString = "No Activo";
	     	}
        return estadoString;
    }
    
    public static void displayInventory(Productos[] productos) {
        for (Productos producto : productos) {
        	System.out.println("-------------------------------------------");
            System.out.println("Informacion del producto:");
            System.out.println("Numero Id: " + producto.getID());
            System.out.println("Nombre: " + producto.getNombre());
            System.out.println("Cantidad: " + producto.getCantidad());
            System.out.println("Precio: " + producto.getPrecio());
            System.out.println("Estado: " + producto.getEstado());
            System.out.println();
        }
    }
    
    public static void agregarStock(Productos[] productos) {
        int elegirproducto = ProducTester.getProductNumber(productos, new Scanner(System.in));
        System.out.print("Ingrese la cantidad de stock a agregar: ");
        int cantidadAgregar = new Scanner(System.in).nextInt();
        productos[elegirproducto].setCantidad(productos[elegirproducto].getCantidad() + cantidadAgregar);
    }

    public static void deducirStock(Productos[] productos) {
        int elegirproducto = ProducTester.getProductNumber(productos, new Scanner(System.in));
        System.out.print("Ingrese la cantidad de stock a deducir: ");
        int cantidadDeducir = new Scanner(System.in).nextInt();
        if (productos[elegirproducto].getCantidad() >= cantidadDeducir) {
            productos[elegirproducto].setCantidad(productos[elegirproducto].getCantidad() - cantidadDeducir);
        } else {
            System.out.println("No hay suficiente stock para deducir.");
        }
    }

    public static void DesordenarProductos(Productos[] productos) {
        // Implementar lógica para desordenar los productos
        // Puedes utilizar un algoritmo de ordenamiento como el algoritmo de Fisher-Yates
        for (int i = productos.length - 1; i > 0; i--) {
            int index = (int) (Math.random() * (i + 1));
            Productos temp = productos[index];
            productos[index] = productos[i];
            productos[i] = temp;
        }
    }

    public void setCantidad(int cantidad) {
        this.Cantidad = cantidad;
    }
}
