package ejer7SistemaDeTransport;

public class Autobus extends Transporte{
	public Autobus(int capacidad, double velocidad) {
		super(capacidad, velocidad);
		// TODO Auto-generated constructor stub
	}

	public void mover (){
		System.out.println("El autobus esta lleno.");
		}
}

