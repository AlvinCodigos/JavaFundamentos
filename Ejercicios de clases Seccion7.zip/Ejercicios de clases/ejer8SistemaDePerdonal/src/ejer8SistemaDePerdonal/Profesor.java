package ejer8SistemaDePerdonal;

public class Profesor extends Persona{

	public void Trabajar() {
		System.out.println("El Profesor está wacheando");
	}
}
