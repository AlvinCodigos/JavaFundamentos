package ejer4SistemasDeAnimales;

public class Principal {

	public static void main(String[] args) {
		Animal[] MiAnimal = new Animal[] {new Gato(),new Perro(),new Vaca()};
		
		for (Animal animal : MiAnimal) {
			animal.HacerSonido();
		}
		System.out.println("------------------------------------------------");
		Animal ANIMAL;
		ANIMAL=new Gato();
		ANIMAL.HacerSonido();
		ANIMAL=new Perro();
		ANIMAL.HacerSonido();
		ANIMAL=new Vaca();
		ANIMAL.HacerSonido();
		
	}

}
