package ejer2SistemaDePagosEmpleados;

public class EmpleadoTiempoCompleto extends Empleados{
	public EmpleadoTiempoCompleto(String nombre, double salario) {
        super(nombre, salario);
    }
	@Override
	public double calcularPago() {
		return salario *2.5;
	}

}
