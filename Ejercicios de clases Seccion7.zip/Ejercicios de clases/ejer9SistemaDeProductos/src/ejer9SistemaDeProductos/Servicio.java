package ejer9SistemaDeProductos;

public class Servicio extends Vendible{
	public String Nombre;
	public double Precio;
	public Servicio(String Nombre, double Precio) {
		this.Nombre=Nombre;
		this.Precio=Precio;
	}
	@Override
	public void Vender() {
		System.out.println("El Servicio: "+Nombre+" fue vendido en "+Precio+" Bs.");
	}
}
