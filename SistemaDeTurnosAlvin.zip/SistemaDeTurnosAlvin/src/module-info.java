/**
 * 
 */
/**
 * 
 */
module SistemaDeTurnosAlvin {
	requires java.desktop;
}