package FormularioDise;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;


import javax.swing.JTextField;
import javax.swing.JSeparator;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;
import java.awt.Cursor;
import javax.swing.border.TitledBorder;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.util.Arrays;

public class Login extends JFrame implements MouseListener, MouseMotionListener {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtUsuario;
	private JPasswordField txtPassword;
	private JLabel lblCerar;
	
	int xMouse, yMouse;
	private JPanel panelMover;
	private JLabel lblEntrar;
	private JPanel btnExit_1;
	private JPanel panelEntrar;
	private String usuario;
	private String password;
	private JLabel txtMensaje;


	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public Login() {
		setLocationByPlatform(true);
		setBackground(new Color(16, 182, 165));
		setUndecorated(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 599, 313);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(16, 182, 165));
		panel.setBounds(0, 0, 600, 313);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblLogin = new JLabel("INICIAR SESION");
		lblLogin.setFont(new Font("Franklin Gothic Heavy", Font.BOLD, 50));
		lblLogin.setBackground(new Color(240, 240, 240));
		lblLogin.setBounds(112, 22, 397, 71);
		panel.add(lblLogin);
		
		JLabel lblUsuario = new JLabel("USUARIO");
		lblUsuario.setFont(new Font("Roboto Black", Font.PLAIN, 15));
		lblUsuario.setBounds(153, 103, 287, 23);
		panel.add(lblUsuario);
		
		JLabel lblPassword = new JLabel("CONTRASEÑA");
		lblPassword.setToolTipText("");
		lblPassword.setFont(new Font("Roboto Black", Font.PLAIN, 15));
		lblPassword.setBounds(153, 165, 287, 23);
		panel.add(lblPassword);
		
		txtUsuario = new JTextField();
		txtUsuario.addMouseListener(this);
		txtUsuario.setFont(new Font("Tahoma", Font.BOLD, 15));
		txtUsuario.setBorder(null);
		txtUsuario.setForeground(new Color(214, 214, 214));
		txtUsuario.setBackground(new Color(16, 182, 165));
		txtUsuario.setBounds(153, 128, 287, 19);
		panel.add(txtUsuario);
		txtUsuario.setColumns(10);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(153, 149, 287, 6);
		panel.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(153, 217, 287, 6);
		panel.add(separator_1);
		
		txtPassword = new JPasswordField();
		txtPassword.setText("**********");
		txtPassword.addMouseListener(this);
		txtPassword.setFont(new Font("Tahoma", Font.BOLD, 15));
		txtPassword.setToolTipText("");
		txtPassword.setBorder(null);
		txtPassword.setForeground(new Color(214, 214, 214));
		txtPassword.setBackground(new Color(16, 182, 165));
		txtPassword.setBounds(153, 196, 287, 19);
		panel.add(txtPassword);
		
		panelEntrar = new JPanel();
		panelEntrar.addMouseListener(this);
		panelEntrar.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(255, 255, 0)));
		panelEntrar.setBackground(new Color(2, 166, 71));
		panelEntrar.setBounds(243, 233, 100, 44);
		panel.add(panelEntrar);
		panelEntrar.setLayout(null);
		
		lblEntrar = new JLabel("ENTRAR");
		lblEntrar.addMouseListener(this);
		lblEntrar.setHorizontalAlignment(SwingConstants.CENTER);
		lblEntrar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblEntrar.setForeground(new Color(255, 255, 255));
		lblEntrar.setFont(new Font("Roboto Black", Font.BOLD, 15));
		lblEntrar.setBounds(0, 0, 100, 44);
		panelEntrar.add(lblEntrar);
		
		panelMover = new JPanel();
		panelMover.addMouseMotionListener(this);
		panelMover.addMouseListener(this);
		panelMover.setBackground(new Color(16, 182, 165));
		panelMover.setBounds(0, 0, 600, 36);
		panel.add(panelMover);
		panelMover.setLayout(null);
		
		btnExit_1 = new JPanel();
		btnExit_1.setBounds(0, 0, 38, 36);
		panelMover.add(btnExit_1);
		btnExit_1.addMouseListener(this);
		btnExit_1.setLayout(null);
		
		lblCerar = new JLabel("X");
		lblCerar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblCerar.setBounds(0, 0, 37, 36);
		btnExit_1.add(lblCerar);
		lblCerar.addMouseListener(this);
		lblCerar.setHorizontalAlignment(SwingConstants.CENTER);
		lblCerar.setFont(new Font("Tahoma", Font.BOLD, 20));
		
		txtMensaje = new JLabel("");
		txtMensaje.setForeground(new Color(255, 0, 128));
		txtMensaje.setToolTipText("");
		txtMensaje.setFont(new Font("Roboto Black", Font.PLAIN, 15));
		txtMensaje.setBounds(153, 287, 287, 23);
		panel.add(txtMensaje);
	}
	public void mouseClicked(MouseEvent e) {
		if (e.getSource() == lblCerar) {
			handleLblCerarMouseClicked(e);
		}
		if (e.getSource() == lblEntrar) {
			handleLblEntrarMouseClicked(e);
		}
		
	}
	//Mouse por encima la etiqueta
	public void mouseEntered(MouseEvent e) {
		//etiqueta entrar
		if (e.getSource() == lblEntrar) {
			handlePanelEntrarMouseEntered(e);
		}
		//etiqueta cerrar
		if (e.getSource() == lblCerar) {
			handleLblCerarMouseouseEntered(e);
		}
		
	}
	protected void handleLblCerarMouseouseEntered(MouseEvent btnExit) {
		btnExit_1.setBackground(Color.red);
	}
	public void mouseExited(MouseEvent e) {
		if (e.getSource() == lblCerar) {
			handleLblCerarMouseouseExited(e);
		}
		if (e.getSource() == lblEntrar) {
			handleLblEntrarMouseExit(e);
		}
		
	}
	
	protected void handleLblCerarMouseouseExited(MouseEvent btnExit) {
		btnExit_1.setBackground(Color.white);
	}
	
	public void mousePressed(MouseEvent e) {
		if (e.getSource() == txtPassword) {
			handleTxtPasswordMousePressed(e);
		}
		if (e.getSource() == txtUsuario) {
			handleTxtUsuarioMousePressed(e);
		}
		if (e.getSource() == panelMover) {
			handlePanelMoverMousePressed(e);
		}
		
	}
	public void mouseReleased(MouseEvent e) {
	}
	protected void handleLblCerarMouseClicked(MouseEvent e) {
		int confirm = JOptionPane.showConfirmDialog(null, "Está seguro que desea Salir?", "Exit", JOptionPane.YES_NO_OPTION);
	    if (confirm == JOptionPane.YES_OPTION) {
	        System.exit(0);
	    }
	}
	protected void handlePanelMoverMousePressed(MouseEvent evt) {
		xMouse = evt.getX();
		yMouse = evt.getY();
	}
	public void mouseDragged(MouseEvent e) {
		if (e.getSource() == panelMover) {
			handlePanelMoverMouseDragged(e);
		}
	}
	public void mouseMoved(MouseEvent e) {
	}
	protected void handlePanelMoverMouseDragged(MouseEvent evt) {
		int x = evt.getXOnScreen();
		int y = evt.getYOnScreen();
		this.setLocation(x- xMouse, y- yMouse);
	}
	protected void handleLblEntrarMouseExit(MouseEvent e) {
		//color cuando sales mouse encima la etiqueta Entrar
		Color c = new Color(2,166,71);
		
		panelEntrar.setBackground(c);
	}

	protected void handlePanelEntrarMouseEntered(MouseEvent e) {
		//color cuando pasas mouse encima la etiqueta Entrar
		panelEntrar.setBackground(Color.blue);
		
	}
	protected void handleTxtUsuarioMousePressed(MouseEvent e) {
		Color c = new Color(214,214,214);
		if(txtUsuario.getText().equals("Ingrese el nombre de usuario")) {
			txtUsuario.setText("");
			txtUsuario.setForeground(Color.white);
		}
		if(String.valueOf(txtPassword.getPassword()).isEmpty()) {
			txtPassword.setText("**********");
			txtPassword.setForeground(c);
		}
		
	}
	protected void handleTxtPasswordMousePressed(MouseEvent e) {
		Color b = new Color(214,214,214);
		if(String.valueOf(txtPassword.getPassword()).equals("**********")) {
			txtPassword.setText("");
			txtPassword.setForeground(Color.white);
		}
		if(txtUsuario.getText().isEmpty()) {
			txtUsuario.setText("Ingrese el nombre de usuario");
			txtUsuario.setForeground(b);
		}
		
		
	}
	protected void handleLblEntrarMouseClicked(MouseEvent e) {
		usuario = "ALVIN";
		password = "101010";
		if(txtUsuario.getText().equals(usuario) && Arrays.equals(password.toCharArray(), txtPassword.getPassword())) {
			Menu menu = new Menu();
			menu.setVisible(true);
			this.setVisible(false);
		}else {
			if (txtUsuario.getText().equals("")) {
				txtMensaje.setText("El usuario está vacío papu :'(");
			}else {
				if(String.valueOf(txtPassword.getPassword()).equals("**********")) {
					txtMensaje.setText("No se introdujo nada en contraseña papu");
				}else {
					if(String.valueOf(txtPassword.getPassword()).equals("")) {
						txtMensaje.setText("introduce la contraseña");
					}else {
						txtMensaje.setText("La cagaste papu, INTENTALO DE NUEVO");
					}
				}
			}
		}
	}
}
