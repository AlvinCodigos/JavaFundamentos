package ejer5SistemDeDispositivosElectronicos;

public class Television extends Encendible {

	@Override
	public void encender() {
		System.out.println("La television extá en mal estado mi kimg :(");
	}
}
