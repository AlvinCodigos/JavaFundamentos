package ejer4SistemasDeAnimales;

public class Perro extends Animal {
	@Override
	public void HacerSonido() {
		System.out.println("El Perro hace Wau");
	}

}
