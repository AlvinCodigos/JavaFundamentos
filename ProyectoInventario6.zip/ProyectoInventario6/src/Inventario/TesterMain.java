package Inventario;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TesterMain {
	public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        int maxSize = -1; // Inicializamos con un valor que falle en el ciclo

        do {
            try {
                System.out.print("Ingresa el número de productos que deseas agregar: ");
                System.out.println("Si Ingresa el valor 0 no se agregarán productos papu:");
                maxSize = leer.nextInt();

                if (maxSize < 0) {
                    System.out.println("El valor ingresado no es Valido mi rey.");
                }
            } catch (InputMismatchException e) {
                System.out.println("El tipo de dato no es valido papu. :(");
                leer.next(); // Limpiar el buffer de entrada
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                leer.next(); // Limpiar el buffer de entrada
            }
        } while (maxSize < 0);

        if (maxSize == 0) {
            System.out.println("No se Requieren Productos");
        } else {
        	Productos[] Producto = new Productos[maxSize];

            for (int i = 0; i < maxSize; i++) {
            	System.out.print("Ingrese el Numero ID del Producto: ");
                int ID = leer.nextInt();
                System.out.print("Ingrese el Nombre del Producto: ");
                String Nombre = leer.next();
                System.out.print("Ingrese la Cantidad del Producto: ");
                int Cantidad = leer.nextInt();
                System.out.print("Ingrese el Precio del Producto: ");
                double Precio = leer.nextDouble();
                System.out.print("Ingrese el Estado del Producto(1 Activo/ 0 no activo): ");
                int disponible = leer.nextInt();
       	     	boolean Estado = disponible == 1;
       	     	

                

                Producto[i] = new Productos(ID, Nombre, Cantidad,Precio, Estado);
                
            }
            

            for (Productos Productos : Producto) {
                System.out.println("Product Information:");
                System.out.println("Numero Id: " + Productos.getID());
                System.out.println("Nombre: " + Productos.getNombre());
                System.out.println("Cantidad: " + Productos.getCantidad());
                System.out.println("Precio: " + Productos.getPrecio());
                System.out.println("Estado: " + Productos.getEstado());
                System.out.println();
            }
        }
    }
}

