package FormularioDise;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import java.awt.Cursor;
import javax.swing.UIManager;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

public class Menu extends JFrame implements MouseListener, MouseMotionListener {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JButton btnCrearFicha;
	private JLabel lblNewLabel;
	int xMouse, yMouse;
	private JButton btnAtenderPaciente;
	private JButton btnPantalla;
	private JButton btnConfiguracion;
	private JPanel panelMover;
	private JPanel btnExit;
	private JLabel lblCerrar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu frame = new Menu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Menu() {
		setLocationByPlatform(true);
		setUndecorated(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 885, 365);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panelPrincipalFondo = new JPanel();
		panelPrincipalFondo.setBackground(new Color(16, 182, 165));
		panelPrincipalFondo.setBounds(0, 0, 885, 365);
		contentPane.add(panelPrincipalFondo);
		panelPrincipalFondo.setLayout(null);
		
		JPanel panelTitulo = new JPanel();
		panelTitulo.setBackground(new Color(255, 255, 255));
		panelTitulo.setBounds(0, 0, 885, 127);
		panelPrincipalFondo.add(panelTitulo);
		panelTitulo.setLayout(null);
		
		lblNewLabel = new JLabel("SISTEMA DE TURNOS");
		lblNewLabel.setBackground(new Color(222, 222, 222));
		lblNewLabel.addMouseMotionListener(this);
		lblNewLabel.addMouseListener(this);
		lblNewLabel.setFont(new Font("Roboto Black", Font.PLAIN, 80));
		lblNewLabel.setBounds(43, 35, 798, 82);
		panelTitulo.add(lblNewLabel);
		
		panelMover = new JPanel();
		panelMover.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		panelMover.addMouseListener(this);
		panelMover.addMouseMotionListener(this);
		panelMover.setLayout(null);
		panelMover.setBackground(new Color(255, 255, 255));
		panelMover.setBounds(0, 0, 885, 36);
		panelTitulo.add(panelMover);
		
		btnExit = new JPanel();
		btnExit.addMouseListener(this);
		btnExit.setLayout(null);
		btnExit.setBackground(new Color(222, 222, 222));
		btnExit.setBounds(0, 0, 40, 37);
		panelMover.add(btnExit);
		
		lblCerrar = new JLabel("X");
		lblCerrar.addMouseListener(this);
		lblCerrar.setHorizontalAlignment(SwingConstants.CENTER);
		lblCerrar.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblCerrar.setBackground(new Color(222, 222, 222));
		lblCerrar.setBounds(0, 0, 40, 37);
		btnExit.add(lblCerrar);
		
		btnCrearFicha = new JButton("Crear Ficha");
		btnCrearFicha.addMouseListener(this);
		btnCrearFicha.setForeground(new Color(255, 255, 255));
		btnCrearFicha.setBorder(UIManager.getBorder("TableHeader.cellBorder"));
		btnCrearFicha.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnCrearFicha.setVerticalTextPosition(SwingConstants.BOTTOM);
		btnCrearFicha.setHorizontalTextPosition(SwingConstants.CENTER);
		btnCrearFicha.setIcon(new ImageIcon(Menu.class.getResource("/recursos/recursos/ficha1.png")));
		btnCrearFicha.setFont(new Font("Roboto Black", Font.PLAIN, 17));
		btnCrearFicha.setBackground(new Color(16, 154, 85));
		btnCrearFicha.setBounds(38, 173, 176, 145);
		panelPrincipalFondo.add(btnCrearFicha);
		
		btnAtenderPaciente = new JButton("Atender Paciente");
		btnAtenderPaciente.addMouseListener(this);
		btnAtenderPaciente.setVerticalTextPosition(SwingConstants.BOTTOM);
		btnAtenderPaciente.setBackground(new Color(58, 121, 250));
		btnAtenderPaciente.setBorder(UIManager.getBorder("TableHeader.cellBorder"));
		btnAtenderPaciente.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnAtenderPaciente.setHorizontalTextPosition(SwingConstants.CENTER);
		btnAtenderPaciente.setIcon(new ImageIcon(Menu.class.getResource("/recursos/recursos/atencion1.png")));
		btnAtenderPaciente.setFont(new Font("Roboto Black", Font.PLAIN, 17));
		btnAtenderPaciente.setForeground(new Color(255, 255, 255));
		btnAtenderPaciente.setBounds(250, 173, 176, 145);
		panelPrincipalFondo.add(btnAtenderPaciente);
		
		btnPantalla = new JButton("Pantalla");
		btnPantalla.addMouseListener(this);
		btnPantalla.setVerticalTextPosition(SwingConstants.BOTTOM);
		btnPantalla.setForeground(new Color(255, 255, 255));
		btnPantalla.setBackground(new Color(252, 231, 44));
		btnPantalla.setBorder(UIManager.getBorder("TableHeader.cellBorder"));
		btnPantalla.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnPantalla.setHorizontalTextPosition(SwingConstants.CENTER);
		btnPantalla.setIcon(new ImageIcon(Menu.class.getResource("/recursos/recursos/pantalla1.png")));
		btnPantalla.setFont(new Font("Roboto Black", Font.PLAIN, 17));
		btnPantalla.setBounds(462, 173, 176, 145);
		panelPrincipalFondo.add(btnPantalla);
		
		btnConfiguracion = new JButton("Configuracion");
		btnConfiguracion.addMouseListener(this);
		btnConfiguracion.setVerticalTextPosition(SwingConstants.BOTTOM);
		btnConfiguracion.setForeground(new Color(255, 255, 255));
		btnConfiguracion.setBackground(new Color(255, 60, 60));
		btnConfiguracion.setBorder(UIManager.getBorder("TableHeader.cellBorder"));
		btnConfiguracion.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnConfiguracion.setHorizontalTextPosition(SwingConstants.CENTER);
		btnConfiguracion.setIcon(new ImageIcon(Menu.class.getResource("/recursos/recursos/config1.png")));
		btnConfiguracion.setFont(new Font("Roboto Black", Font.PLAIN, 17));
		btnConfiguracion.setBounds(670, 173, 176, 145);
		panelPrincipalFondo.add(btnConfiguracion);
	}
	public void mouseClicked(MouseEvent e) {
		if (e.getSource() == lblCerrar) {
			handleLblCerrarMouseClicked(e);
		}
		if (e.getSource() == btnPantalla) {
			handleBtnPantallaMouseClicked(e);
		}
		if (e.getSource() == btnAtenderPaciente) {
			handleBtnAtenderPacienteMouseClicked(e);
		}
		if (e.getSource() == btnCrearFicha) {
			handlebtnCrearFichaMouseClicked(e);
		}
		if (e.getSource() == btnConfiguracion) {
			handleBtnConfiguracionMouseClicked(e);
		}
	}
	public void mouseEntered(MouseEvent e) {
		if (e.getSource() == lblCerrar) {
			handleBtnExitMouseEntered(e);
		}
		if (e.getSource() == btnCrearFicha) {
			handleBtnCrearFichaMouseEntered(e);
		}
		if (e.getSource() == btnAtenderPaciente) {
			handleBtnAtenderPacienteMouseEntered(e);
		}
		if (e.getSource() == btnPantalla) {
			handleBtnPantallaMouseEntered(e);
		}
		if (e.getSource() == btnConfiguracion) {
			handleBtnConfiguracionMouseEntered(e);
		}
	}
	public void mouseExited(MouseEvent e) {
		if (e.getSource() == btnCrearFicha) {
			handleBtnCrearFichaMouseExited(e);
		}
		if (e.getSource() == btnAtenderPaciente) {
			handleBtnAtenderPacienteMouseExited(e);
		}
		if (e.getSource() == btnPantalla) {
			handleBtnPantallaMouseExited(e);
		}
		if (e.getSource() == btnConfiguracion) {
			handleBtnConfiguracionMouseExited(e);
		}
		if (e.getSource() == lblCerrar) {
			handleLblCerrarMosueExited(e);
		}
	}
	public void mousePressed(MouseEvent e) {
		if (e.getSource() == panelMover) {
			handlePanelMoverMousePressed(e);
		}
	}
	public void mouseReleased(MouseEvent e) {
	}
	protected void handlePanelMoverMousePressed(MouseEvent evt) {
		xMouse = evt.getX();
		yMouse = evt.getY();
	}
	protected void handleBtnCrearFichaMouseEntered(MouseEvent e) {
		btnCrearFicha.setBackground(Color.DARK_GRAY);
	}
	protected void handleBtnAtenderPacienteMouseEntered(MouseEvent e) {
		btnAtenderPaciente.setBackground(Color.DARK_GRAY);
	}
	protected void handleBtnPantallaMouseEntered(MouseEvent e) {
		btnPantalla.setBackground(Color.DARK_GRAY);
	}
	protected void handleBtnConfiguracionMouseEntered(MouseEvent e) {
		btnConfiguracion.setBackground(Color.DARK_GRAY);
	}
	protected void handleBtnCrearFichaMouseExited(MouseEvent e) {
		Color c = new Color(16,154,85);
		btnCrearFicha.setBackground(c);
	}
	protected void handleBtnAtenderPacienteMouseExited(MouseEvent e) {
		Color c = new Color(58,121,250);
		btnAtenderPaciente.setBackground(c);
	}
	protected void handleBtnPantallaMouseExited(MouseEvent e) {
		Color c = new Color(252,231,44);
		btnPantalla.setBackground(c);
	}
	protected void handleBtnConfiguracionMouseExited(MouseEvent e) {
		Color c = new Color(255,60,60);
		btnConfiguracion.setBackground(c);
	}
	
	public void mouseDragged(MouseEvent e) {
		if (e.getSource() == panelMover) {
			handlePanelMoverMouseDragged(e);
		}
	}
	
	public void mouseMoved(MouseEvent e) {
	}
	 protected void handlebtnCrearFichaMouseClicked(MouseEvent evt) {
		 CrearFicha  crearFicha = new CrearFicha();
		 crearFicha.setVisible(true);
		 this.setVisible(false);
	}
	protected void handleBtnAtenderPacienteMouseClicked(MouseEvent e) {
		AtenderPaciente atencion = new AtenderPaciente();
		atencion.setVisible(true);
		this.setVisible(false);
	}
	protected void handleBtnPantallaMouseClicked(MouseEvent e) {
		Pantalla pantalla = new Pantalla();
		pantalla.setVisible(true);
		this.setVisible(false);
	}
	protected void handleBtnConfiguracionMouseClicked(MouseEvent e) {
		Configuracion configuracion = new Configuracion();
		configuracion.setVisible(true);
		this.setVisible(false);
	}
	protected void handlePanelMoverMouseDragged(MouseEvent evt) {
		int x = evt.getXOnScreen();
		int y = evt.getYOnScreen();
		this.setLocation(x- xMouse, y- yMouse);
	}
	protected void handleLblCerrarMouseClicked(MouseEvent e) {
		Login login = new Login();
		login.setVisible(true);
		this.setVisible(false);
	}
	protected void handleBtnExitMouseEntered(MouseEvent e) {
		btnExit.setBackground(Color.red);
	}
	protected void handleLblCerrarMosueExited(MouseEvent e) {
		//color cuando sales mouse encima la etiqueta X
		Color c = new Color(222,222,222);
		btnExit.setBackground(c);
	}
}
