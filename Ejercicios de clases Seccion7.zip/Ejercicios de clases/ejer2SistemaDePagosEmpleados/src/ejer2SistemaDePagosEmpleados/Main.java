package ejer2SistemaDePagosEmpleados;

public class Main {
	public static void main(String[] args) {
        Empleados empleadoTiempoCompleto = new EmpleadoTiempoCompleto("Juan", 5000);
        Empleados empleadoMedioTiempo = new EmpleadoMedioTiempo("Maria", 3000);

        System.out.println("Empleado Tiempo Completo:");
        System.out.println("Nombre: " + empleadoTiempoCompleto.nombre);
        System.out.println("Salario: " + empleadoTiempoCompleto.salario);
        System.out.println("Pago: " + empleadoTiempoCompleto.calcularPago());

        System.out.println("\nEmpleado Medio Tiempo:");
        System.out.println("Nombre: " + empleadoMedioTiempo.nombre);
        System.out.println("Salario: " + empleadoMedioTiempo.salario);
        System.out.println("Pago: " + empleadoMedioTiempo.calcularPago());
        
    }
}
