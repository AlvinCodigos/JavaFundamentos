package Inventario;

public class Productos {
	private int ID;
	private String Nombre;
    private int Cantidad;
    private double Precio;
	private boolean Estado = true;

    public Productos(int ID, String Nombre, int Cantidad, double Precio, boolean Estado) {
        this.ID = ID;
        this.Nombre = Nombre;
        this.Cantidad = Cantidad;
        this.Precio = Precio;
    	this.Estado = Estado;
    }
    
    public int getID() {
        return ID;
    }

    public String getNombre() {
        return Nombre;
    }

    public int getCantidad() {
        return Cantidad;
    }

    public double getPrecio() {
        return Precio;
    }
    
    public String getEstado() {
	     	String estadoString;

	     	if (Estado) {
	     		estadoString = "Activo";
	     	} else {
	     		estadoString = "No Activo";
	     	}
        return estadoString;
    }
    
	
}
