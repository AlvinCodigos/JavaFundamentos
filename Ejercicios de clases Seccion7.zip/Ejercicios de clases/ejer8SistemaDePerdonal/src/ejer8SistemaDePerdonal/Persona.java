package ejer8SistemaDePerdonal;

public class Persona {

	public void Trabajar() {
		
	}
}
