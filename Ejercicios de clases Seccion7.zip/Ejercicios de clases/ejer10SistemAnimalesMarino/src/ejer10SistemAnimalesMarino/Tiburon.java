package ejer10SistemAnimalesMarino;

public class Tiburon extends AnimalMarino {
	public void nadar() {
		System.out.println("El Tiburon es maloso");
	}
}
