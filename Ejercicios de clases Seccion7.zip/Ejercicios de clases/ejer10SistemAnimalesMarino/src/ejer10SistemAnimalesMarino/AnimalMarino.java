package ejer10SistemAnimalesMarino;

public class AnimalMarino {
	public void nadar() {
	
	}
}
