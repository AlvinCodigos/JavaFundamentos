package ejer10SistemAnimalesMarino;

public class Delfin extends AnimalMarino {
	public void nadar() {
		System.out.println("Al Delfin no le gusta el maní");
	}
}
