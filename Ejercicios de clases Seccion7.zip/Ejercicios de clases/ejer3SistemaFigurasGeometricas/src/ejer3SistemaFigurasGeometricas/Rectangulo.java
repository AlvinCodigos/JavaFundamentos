package ejer3SistemaFigurasGeometricas;

public class Rectangulo extends Figura{
	double base=2;
	double altura=5;
	double total;

    //public Rectangulo(double base, double altura) {
    //    this.base = base;
    //    this.altura=altura;
    //}
	
    @Override
    public double calcularArea() {
        total= base* altura;
        System.out.println(total);
        return total;
    }
}
