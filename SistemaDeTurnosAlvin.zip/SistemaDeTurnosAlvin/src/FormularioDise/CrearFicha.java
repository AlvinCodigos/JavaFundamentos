package FormularioDise;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import java.awt.Font;
import javax.swing.JTextField;

import javax.swing.border.TitledBorder;
import javax.swing.SwingConstants;
import javax.swing.JTable;
import java.awt.Rectangle;
import javax.swing.UIManager;
import java.awt.event.MouseListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.awt.Cursor;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import Operaciones.Pacientes;

import javax.swing.DefaultComboBoxModel;


public class CrearFicha extends JFrame implements MouseListener, MouseMotionListener {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JPanel panelMover;
	int xMouse, yMouse;
	private JLabel lblCerrar;
	private JPanel btnExit;
	private JLabel lblCrearFicha;
	private JPanel btnCrearFicha;
	private JTable tablaFichas;
	private JTextField txtNombrePaciente;
	private JTextField txtEstado;
	private JTextField txtFicha;
	private DefaultTableModel mt;
	private JComboBox comboBoxHora;
	private JComboBox comboBoxDia;
	private JComboBox comboBoxConsultorio;
	private JTextField txtFecha;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CrearFicha frame = new CrearFicha();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CrearFicha() {
		setLocationByPlatform(true);
		setUndecorated(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 613, 596);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(16, 182, 165));
		panel.setBounds(0, 0, 613, 596);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panelCrearFicha = new JPanel();
		panelCrearFicha.setBackground(new Color(192, 192, 192));
		panelCrearFicha.setBounds(56, 92, 493, 144);
		panel.add(panelCrearFicha);
		panelCrearFicha.setLayout(null);
		
		comboBoxHora = new JComboBox();
		comboBoxHora = new JComboBox();
		comboBoxHora.addItem("08: 00");
		comboBoxHora.addItem("08: 30");
		comboBoxHora.addItem("09: 00");
		comboBoxHora.addItem("09: 30");
		comboBoxHora.addItem("10: 00");
		comboBoxHora.addItem("10: 30");
		comboBoxHora.setBounds(147, 39, 106, 24);
		panelCrearFicha.add(comboBoxHora);
		comboBoxHora.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JLabel lblHora = new JLabel("HORA");
		lblHora.setBounds(147, 5, 42, 24);
		panelCrearFicha.add(lblHora);
		lblHora.setFont(new Font("Roboto", Font.BOLD, 15));
		
		JLabel lblNewLabel = new JLabel("DÍA");
		lblNewLabel.setFont(new Font("Roboto", Font.BOLD, 15));
		lblNewLabel.setBounds(10, 10, 34, 24);
		panelCrearFicha.add(lblNewLabel);
		
		comboBoxDia = new JComboBox();
		comboBoxDia.addItem("Lunes");
		comboBoxDia.addItem("Martes");
		comboBoxDia.addItem("Miércoles");
		comboBoxDia.addItem("Jueves");
		comboBoxDia.addItem("Viernes");
		comboBoxDia.setFont(new Font("Tahoma", Font.PLAIN, 13));
		comboBoxDia.setBounds(10, 39, 127, 24);
		panelCrearFicha.add(comboBoxDia);
		
		JLabel lblNewLabel_2 = new JLabel("CONSULTORIO");
		lblNewLabel_2.setFont(new Font("Roboto", Font.BOLD, 15));
		lblNewLabel_2.setBounds(263, 10, 180, 24);
		panelCrearFicha.add(lblNewLabel_2);
		
		comboBoxConsultorio = new JComboBox();
		comboBoxConsultorio.addItem("Med. General");
		comboBoxConsultorio.addItem("Odontología");
		comboBoxConsultorio.addItem("Oculista");
		comboBoxConsultorio.addItem("Pediatría");
		comboBoxConsultorio.setFont(new Font("Tahoma", Font.PLAIN, 13));
		comboBoxConsultorio.setBounds(263, 39, 214, 24);
		panelCrearFicha.add(comboBoxConsultorio);
		
		txtNombrePaciente = new JTextField();
		txtNombrePaciente.setFont(new Font("Tahoma", Font.PLAIN, 13));
		txtNombrePaciente.setColumns(10);
		txtNombrePaciente.setBounds(10, 102, 177, 24);
		panelCrearFicha.add(txtNombrePaciente);
		
		JLabel lblNewLabel_3 = new JLabel("NOMBRE DE PACIENTE");
		lblNewLabel_3.setFont(new Font("Roboto", Font.BOLD, 15));
		lblNewLabel_3.setBounds(12, 73, 177, 24);
		panelCrearFicha.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("ESTADO");
		lblNewLabel_4.setFont(new Font("Roboto", Font.BOLD, 15));
		lblNewLabel_4.setBounds(197, 73, 106, 24);
		panelCrearFicha.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("CÓDIGO DE FICHA");
		lblNewLabel_5.setFont(new Font("Roboto", Font.BOLD, 15));
		lblNewLabel_5.setBounds(323, 73, 127, 24);
		panelCrearFicha.add(lblNewLabel_5);
		
		txtEstado = new JTextField();
		txtEstado.setBackground(new Color(192, 192, 192));
		txtEstado.setText("Espera");
		txtEstado.setName("");
		txtEstado.setFont(new Font("Tahoma", Font.PLAIN, 13));
		txtEstado.setEditable(false);
		txtEstado.setColumns(10);
		txtEstado.setBounds(197, 102, 116, 24);
		panelCrearFicha.add(txtEstado);
		
		txtFicha = new JTextField();
		txtFicha.setBackground(new Color(192, 192, 192));
		txtFicha.setFont(new Font("Tahoma", Font.PLAIN, 13));
		txtFicha.setColumns(10);
		txtFicha.setBounds(323, 102, 154, 24);
		panelCrearFicha.add(txtFicha);
		
		btnCrearFicha = new JPanel();
		btnCrearFicha.addMouseListener(this);
		btnCrearFicha.setLayout(null);
		btnCrearFicha.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(255, 255, 0)));
		btnCrearFicha.setBackground(new Color(2, 166, 71));
		btnCrearFicha.setBounds(211, 239, 191, 36);
		panel.add(btnCrearFicha);
		
		lblCrearFicha = new JLabel("CREAR FICHA");
		lblCrearFicha.addMouseListener(this);
		lblCrearFicha.setHorizontalAlignment(SwingConstants.CENTER);
		lblCrearFicha.setForeground(Color.WHITE);
		lblCrearFicha.setFont(new Font("Roboto Black", Font.BOLD, 15));
		lblCrearFicha.setBounds(0, 0, 191, 36);
		btnCrearFicha.add(lblCrearFicha);
		
		JLabel lblCrearFciha = new JLabel("CREAR FICHA");
		lblCrearFciha.setFont(new Font("Franklin Gothic Heavy", Font.BOLD, 50));
		lblCrearFciha.setBackground(UIManager.getColor("Button.background"));
		lblCrearFciha.setBounds(115, 36, 335, 46);
		panel.add(lblCrearFciha);
		
		panelMover = new JPanel();
		panelMover.addMouseMotionListener(this);
		panelMover.addMouseListener(this);
		panelMover.setLayout(null);
		panelMover.setBackground(new Color(16, 182, 165));
		panelMover.setBounds(0, 0, 613, 36);
		panel.add(panelMover);
		
		btnExit = new JPanel();
		btnExit.addMouseListener(this);
		btnExit.setLayout(null);
		btnExit.setBackground(new Color(222, 222, 222));
		btnExit.setBounds(0, 0, 40, 37);
		panelMover.add(btnExit);
		
		lblCerrar = new JLabel("X");
		lblCerrar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblCerrar.addMouseListener(this);
		lblCerrar.setHorizontalAlignment(SwingConstants.CENTER);
		lblCerrar.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblCerrar.setBackground(new Color(222, 222, 222));
		lblCerrar.setBounds(0, 0, 40, 37);
		btnExit.add(lblCerrar);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBackground(new Color(255, 62, 62));
		scrollPane.setBounds(20, 285, 572, 285);
		panel.add(scrollPane);
		scrollPane.setViewportView(tablaFichas);
		
		
		mt = new DefaultTableModel();
		String titulo[] = {
				"N°",
				"Nombre Paciente",
				"Consultorio",
				"Día",
				"hora",
				"CodigoFicha",
				"Fecha",
				"Estado"
		};
		mt.setColumnIdentifiers(titulo);
		tablaFichas = new JTable(mt);
		tablaFichas.setBounds(20, 285, 572, 285);
		//tablaFichas.setFont(new Font("Tahoma", Font.PLAIN, 12));

		scrollPane.setViewportView(tablaFichas);
		
		txtFecha = new JTextField();
		txtFecha.setBackground(new Color(16, 182, 165));
		txtFecha.setFont(new Font("Tahoma", Font.PLAIN, 13));
		txtFecha.setEditable(false);
		txtFecha.setColumns(10);
		txtFecha.setBounds(459, 58, 89, 24);
		panel.add(txtFecha);
		// Crear un objeto de la clase que recibirá los valores
        
        
	}
    public String getValorSeleccionado() {
        return (String) comboBoxConsultorio.getSelectedItem();
    }
	public void llenarTabla() {
		
	}

	
	
	public void mouseClicked(MouseEvent e) {
		if (e.getSource() == lblCrearFicha) {
			handleLblCrearFichaMouseClicked(e);
		}
		if (e.getSource() == lblCerrar) {
			handleLblXMouseClicked(e);
		}
	}
	public void mouseEntered(MouseEvent e) {
		if (e.getSource() == lblCrearFicha) {
			handleBtnCrearFichaMouseEntered(e);
		}
		if (e.getSource() == lblCerrar) {
			handleBtnExitMouseEntered(e);
		}
	}
	public void mouseExited(MouseEvent e) {
		Color c = new Color(222,222,222);
		btnExit.setBackground(c);
		Color a = new Color(2,166,71);
		btnCrearFicha.setBackground(a);
	}
	public void mousePressed(MouseEvent e) {
		if (e.getSource() == panelMover) {
			handlePanelMoverMousePressed(e);
		}
	}
	public void mouseReleased(MouseEvent e) {
	}
	protected void handlePanelMoverMousePressed(MouseEvent evt) {
		xMouse = evt.getX();
		yMouse = evt.getY();
	}
	public void mouseDragged(MouseEvent e) {
		if (e.getSource() == panelMover) {
			handlePanelMoverMouseDragged(e);
		}
	}
	public void mouseMoved(MouseEvent e) {
	}
	protected void handlePanelMoverMouseDragged(MouseEvent evt) {
		int x = evt.getXOnScreen();
		int y = evt.getYOnScreen();
		this.setLocation(x- xMouse, y- yMouse);
	}
	protected void handleLblXMouseClicked(MouseEvent e) {
		Menu menu = new Menu();
		menu.setVisible(true);
		this.setVisible(false);
	}
	protected void handleBtnExitMouseEntered(MouseEvent e) {
		btnExit.setBackground(Color.red);
	}
	private int contador=0;

	protected void handleLblCrearFichaMouseClicked(MouseEvent e) {
	    try {
	        contador++;
	        int numero = contador;
	        LocalDate fechaActual = LocalDate.now();
	        DayOfWeek diaSemana = fechaActual.getDayOfWeek();
	        String dia;

	        switch (diaSemana) {
	            case MONDAY:
	                dia = "Lunes";
	                break;
	            case TUESDAY:
	                dia = "Martes";
	                break;
	            case WEDNESDAY:
	                dia = "Miércoles";
	                break;
	            case THURSDAY:
	                dia = "Jueves";
	                break;
	            case FRIDAY:
	                dia = "Viernes";
	                break;
	            default:
	                dia = "";
	                break;
	        }

	        comboBoxDia.setSelectedItem(dia); 

	        String fecha = fechaActual.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")); 

	        String hora = comboBoxHora.getSelectedItem().toString();
	        String numeroHora = getNumHora(hora);
	        String consultorio = comboBoxConsultorio.getSelectedItem().toString();
	        String letraConsultorio = getLetraConsultorio(consultorio);
	        String nombrePciente = String.valueOf(txtNombrePaciente.getText());
	        String estado = String.valueOf(txtEstado.getText());
	        String codFicha;

	        if (!letraConsultorio.isEmpty()) {
	            codFicha = letraConsultorio + "-" + numeroHora;
	        } else {
	            codFicha = numeroHora;
	        }

	        txtFicha.setText(codFicha);

	        boolean codFichaExists = false;
	        for (int i = 0; i < mt.getRowCount(); i++) {
	            if (mt.getValueAt(i, 5).equals(codFicha) && mt.getValueAt(i, 6).equals(fecha)) {
	                codFichaExists = true;
	                break;
	            }
	        }

	        if (codFichaExists) {
	            throw new Exception("Error: Código de ficha ya existe para este día");
	        }

	        comboBoxHora.setSelectedItem("");
	        comboBoxConsultorio.setSelectedItem("");
	        txtNombrePaciente.setText("");
	        txtFicha.setText("");

	        mt.addRow(new Object[] {numero, nombrePciente, consultorio, dia, hora, codFicha, fecha, estado});
	    } catch (Exception evt) {
	        JOptionPane.showMessageDialog(null, evt.getMessage());
	    }
	}

	private String getLetraConsultorio(String consultorio) {
	    switch (consultorio) {
	        case "Med. General":
	            return "MG";
	        case "Odontología":
	            return "OD";
	        case "Oculista":
	            return "OC";
	        case "Pediatría":
	            return "PDT";
	        default:
	            return "";
	    }
	}
	private String getNumHora(String hora) {
	    switch (hora) {
	        case "08: 00":
	            return "1";
	        case "08: 30":
	            return "2";
	        case "09: 00":
	            return "3";
	        case "09: 30":
	            return "4";
	        case "10: 00":
	            return "5";
	        case "10: 30":
	            return "6";
	        default:
	            return "";
	    }
	}

	protected void handleBtnCrearFichaMouseEntered(MouseEvent e) {
		btnCrearFicha.setBackground(Color.DARK_GRAY);
	}
	protected void handleLblCerrarMosueExited(MouseEvent e) {
		//color cuando sales mouse encima la etiqueta X
		Color c = new Color(222,222,222);
		btnExit.setBackground(c);
	}
}
