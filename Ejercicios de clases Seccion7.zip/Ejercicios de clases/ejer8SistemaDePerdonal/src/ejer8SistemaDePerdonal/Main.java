package ejer8SistemaDePerdonal;


public class Main {

	public static void main(String[] args) {
		Persona mPersona;
		mPersona=new Profesor();
		mPersona.Trabajar();
		mPersona=new Estudiante();
		mPersona.Trabajar();
	}
}
