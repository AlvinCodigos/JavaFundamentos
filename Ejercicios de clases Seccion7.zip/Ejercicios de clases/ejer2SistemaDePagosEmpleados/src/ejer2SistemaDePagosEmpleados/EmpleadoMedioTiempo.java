package ejer2SistemaDePagosEmpleados;

public class EmpleadoMedioTiempo extends Empleados {
	public EmpleadoMedioTiempo(String nombre, double salario) {
        super(nombre, salario);
    }
	@Override
	public double calcularPago() {

		salario = salario*1.5;
		return salario;
	}
}
