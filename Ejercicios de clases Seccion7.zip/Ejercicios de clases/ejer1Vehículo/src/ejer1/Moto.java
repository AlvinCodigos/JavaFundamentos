package ejer1;

public class Moto extends Vehículo {
	public Moto(String Marca, String Modelo) {
        super(Marca, Modelo);
    }
	@Override
	public void Acelerar() {
		System.out.println("La moto no enciende papu");
	}

}
