package ejer7SistemaDeTransport;

public class Tren extends Transporte{
	public Tren(int capacidad, double velocidad) {
		super(capacidad, velocidad);
		// TODO Auto-generated constructor stub
	}

	public void mover (){
		System.out.println("El tren está viejo.");
		}

}
