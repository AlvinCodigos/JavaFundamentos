package ejer7SistemaDeTransport;



public class Main {
	public static void main(String[] args) {
		Transporte miTransporte;
		miTransporte=new Autobus(15,60);
		System.out.println("Cantidad: "+miTransporte.Capacidad);
		System.out.println("Velocidad: "+miTransporte.Velocidad+" km/h");
		miTransporte.mover();
		System.out.println("--------------------------");
		miTransporte=new Tren(40,45);
		System.out.println("Cantidad: "+miTransporte.Capacidad);
		System.out.println("Velocidad: "+miTransporte.Velocidad+" km/h");
		miTransporte.mover();
	}
}
