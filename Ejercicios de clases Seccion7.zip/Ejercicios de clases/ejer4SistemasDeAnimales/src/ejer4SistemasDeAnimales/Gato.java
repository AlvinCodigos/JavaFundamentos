package ejer4SistemasDeAnimales;

public class Gato extends Animal {
	@Override
	public void HacerSonido() {
		System.out.println("El Gato hace miau");
	}

}
