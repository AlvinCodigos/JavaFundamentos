package INVENTARIO;

public class TesterProducto {
		public static void main(String [] args){
		Productos p1 = new Productos();
		Productos p2 = new Productos();
		
		Productos p3 = new Productos(1,"Grandes Exitos",15,9.99);
		Productos p4 = new Productos(2,"Pequeños Exitos",10,9.99);
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		System.out.println(p4);
		
		}
		

}
