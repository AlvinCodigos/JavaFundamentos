package ejer4SistemasDeAnimales;

public class Vaca extends Animal{
	@Override
	public void HacerSonido() {
		System.out.println("La vaca hace muu");
	}

}
