package Inventario;

import java.util.InputMismatchException;
import java.util.Scanner;

public class ProducTester {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int maxSize = getNumProducts(scanner);
        Productos[] productos = new Productos[maxSize];

        addToInventory(productos, scanner);

        while (true) {
            int menuOption = getMenuOption(scanner);
            menuSeleccionado(menuOption, productos, scanner);
        }
    }
	private static void menuSeleccionado(int menuOption, Productos[] productos, Scanner scanner) {
        switch (menuOption) {
            case 1:
                Productos.displayInventory(productos);
                break;
            case 2:
            	Productos.agregarStock(productos);
                // agregar STock
                break;
            case 3:
            	Productos.deducirStock(productos);
                // Deducir STock
                break;
            case 4:
            	Productos.DesordenarProductos(productos);
                // Desordenar Productos
                break;
            case 0:
                System.out.println("Hasta Luego Papu!");
                System.exit(0);
                break;
            default:
                System.out.println("Opcion invalida. Por favor intente de nuevo.");
        }
    }

	public static int getNumProducts(Scanner scanner) {
        int maxSize = 0;
        do {
            try {
                System.out.print("Ingresa el número de productos que deseas agregar: ");
                System.out.println("Si Ingresa el valor 0 no se agregarán productos papu:");
                maxSize = scanner.nextInt();

                if (maxSize < 0) {
                    System.out.println("El valor ingresado no es Valido mi rey.");
                }
            } catch (InputMismatchException e) {
                System.out.println("El tipo de dato no es valido papu. :(");
                scanner.next(); // Limpiar el buffer de entrada
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                scanner.next(); // Limpiar el buffer de entrada
            }
        } while (maxSize < 0);
        return maxSize;
    }

    public static void addToInventory(Productos[] productos, Scanner scanner) {
        for (int i = 0; i < productos.length; i++) {
            System.out.print("Ingrese el Numero ID del Producto: ");
            int ID = scanner.nextInt();
            System.out.print("Ingrese el Nombre del Producto: ");
            String Nombre = scanner.next();
            System.out.print("Ingrese la Cantidad del Producto: ");
            int Cantidad = scanner.nextInt();
            System.out.print("Ingrese el Precio del Producto: ");
            double Precio = scanner.nextDouble();
            System.out.print("Ingrese el Estado del Producto(1 Activo/ 0 no activo): ");
            int disponible = scanner.nextInt();
            boolean Estado = disponible == 1;

            productos[i] = new Productos(ID, Nombre, Cantidad, Precio, Estado);
        }
    }



    public static int getMenuOption(Scanner scanner) {
        int menuOption = 0;
        do {
            try {
                System.out.println("1. Ver Inventario");
                System.out.println("2. Agregar Stock");
                System.out.println("3. Deducir Stock");
                System.out.println("4. Desordenar Product");
                System.out.println("0. Salir");
                System.out.print("Por favor ingrese una opcion: ");
                menuOption = scanner.nextInt();

                if (menuOption < 0 || menuOption > 4) {
                    System.out.println("Opción inválida. Por favor, inténtelo de nuevo.");
                }
            } catch (InputMismatchException e) {
                System.out.println("El tipo de dato no es valido papu. :(");
                scanner.next(); // Limpiar el buffer de entrada
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                scanner.next(); // Limpiar el buffer de entrada
            }
        } while (menuOption < 0 || menuOption > 4);
        return menuOption;
    }
    
    

    public static int getProductNumber(Productos[] productos, Scanner scanner) {
        int elegirproducto = 0;
        do {
            try {
                System.out.println("Seleccione el producto que desea actualizar:");
                for (int i = 0; i < productos.length; i++) {
                    System.out.println((i + 1) + ". " + productos[i].getNombre());
                }
                elegirproducto = scanner.nextInt();

                if (elegirproducto < 1 || elegirproducto > productos.length) {
                    System.out.println("Opción inválida. Por favor, inténtelo de nuevo.");
                }
            } catch (InputMismatchException e) {
                System.out.println("El tipo de dato no es valido papu. :(");
                scanner.next(); // Limpiar el buffer de entrada
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                scanner.next(); // Limpiar el buffer de entrada
            }
        } while (elegirproducto < 1 || elegirproducto > productos.length);
        return elegirproducto - 1;
    }
}