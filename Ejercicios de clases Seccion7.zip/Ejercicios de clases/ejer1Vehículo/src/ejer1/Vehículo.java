package ejer1;

public class Vehículo {

	 String Marca;
     String Modelo;

    public Vehículo(String Marca, String Modelo) {
        this.Marca = Marca;
        this.Modelo = Modelo;
    }
	
	public void Acelerar() {
		System.out.println("El Vehiculo esta en aceleracion");
	}
}
