package ejer6SistemaDeBiblioteca;

public class Libro extends Publicacion {
	public Libro(String titulo, String autor) {
		super(titulo, autor);
		// TODO Auto-generated constructor stub
		
	}
		
		public void MostrarInformacion() {
			
			System.out.println("Este libro es de la vieja Escula mi king.");
			return;
		}
		
}
