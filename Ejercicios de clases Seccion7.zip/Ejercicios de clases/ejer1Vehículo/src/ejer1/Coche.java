package ejer1;

public class Coche extends Vehículo {
	public Coche(String Marca, String Modelo) {
        super(Marca, Modelo);
    }
	@Override
	public void Acelerar() {
		System.out.println("El coche está acelerando rápidamente papu");
	}

}
