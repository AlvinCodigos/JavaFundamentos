package proyecto5InventarioConScanner;

import java.util.Scanner;



public class TesterMain {
	public static void main(String[] args) {
		 Scanner leer = new Scanner(System.in);
		 
		 int tempId;
		 String tempNombre;
		 int tempStock;
		 double tempPrecio;
		 
		 System.out.println("/////////////////////////////////PRODUCTO1/////////////////////////////////////////////");
		 System.out.print("Ingrese el ID del producto: ");
		 tempId =leer.nextInt();
	     System.out.print("Ingrese el nombre del producto: ");
	     tempNombre =leer.next();
	     System.out.print("Ingrese el cantidad stock del producto: ");
	     tempStock =leer.nextInt();
	     System.out.print("Ingrese el precio del producto: ");
	     tempPrecio =leer.nextDouble();
	     System.out.print("Ingrese el estado del producto: ");
	     int disponible = leer.nextInt();
	     boolean estado = disponible == 1? true : false;
	     productos p1 = new productos(tempId,tempNombre,tempStock,tempPrecio,estado);
	     leer.nextLine();
	     System.out.print("/////////////////////////////////PRODUCTO2/////////////////////////////////////////////");
	     System.out.print("Ingrese el ID del producto: ");
		 tempId =leer.nextInt();
	     System.out.print("Ingrese el nombre del producto: ");
	     tempNombre =leer.next();
	     System.out.print("Ingrese el cantidad stock del producto: ");
	     tempStock =leer.nextInt();
	     System.out.print("Ingrese el precio del producto: ");
	     tempPrecio =leer.nextDouble();

	     
	     productos p2 = new productos(tempId,tempNombre,tempStock,tempPrecio,estado);
	     p2.setEstado(true);
	     productos p3 = new productos(1,"Grandes Exitos",15,9.99,estado);
	     productos p4 = new productos(2,"Pequeños Exitos",10,9.99,estado);
	     System.out.println(p1);
	     System.out.println(p2);
	     System.out.println(p3);
	     System.out.println(p4);
	     
	        /*productos producto1 = new productos();

	        System.out.print("Ingrese el ID del producto: ");
	        producto1.setId(leer.nextInt());

	        System.out.print("Ingrese el nombre del producto: ");
	        producto1.setNombre(leer.next());

	        System.out.print("Ingrese el cantidad stock del producto: ");
	        producto1.setCantStock(leer.nextInt());
	        
	        System.out.print("Ingrese el precio del producto: ");
	        producto1.setPrecio(leer.nextDouble());

	        System.out.print("Ingrese si el producto está disponible: ");
	        
	        int disponible = leer.nextInt();
	        boolean estado = disponible == 1? true : false;
	        producto1.setEstado(estado);

	        
	        leer.close();
	        System.out.println(producto1);*/
	        
	}
}
