package ejer5SistemDeDispositivosElectronicos;

public class Encendible {
	public void encender() {
		
	}
}
