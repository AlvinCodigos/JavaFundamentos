package ejer6SistemaDeBiblioteca;

public class Publicacion {

	String titulo;
	String autor;
	public 	Publicacion(String titulo, String autor) {
		this.titulo=titulo;
		this.autor=autor;
	}
	public void MostrarInformacion() {
		
	}
}
