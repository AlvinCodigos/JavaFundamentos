package proyecto5InventarioConScanner;

public class productos {
	private int Id;
	private String Nombre;
	private int cantStock;
	private double Precio;
	private boolean Estado = true;
	
	public productos(){
	}
	public productos(int Id, String Nombre,int cantStock, double Precio,boolean Estado){
	this.Id= Id;
	this.Nombre= Nombre;
	this.cantStock= cantStock;
	this.Precio= Precio;
	this.Estado= Estado;
	}
	public int getId(){
	return Id;
	}
	public void setId(int Id){
	this.Id = Id;
	}
	public String getNombre(){
	return Nombre;
	}
	public void setNombre(String Nombre){
	this.Nombre = Nombre;
	}
	public int getCantStock(){
	return cantStock;
	}
	public void setCantStock (int CantStock){
	this.cantStock = CantStock;
	}
	public double getPrecio(){
	return Precio;
	}
	public void setPrecio (double Precio){
	this.Precio = Precio;
	}
	public boolean getEstado(){
	return Estado;
	}
	public void setEstado (boolean Estado){
	this.Estado = Estado;
	}
	public double getValorInventario() {
		return(Precio*cantStock);
	}
	public String toString(){
	return "\n\n Numero de ID :"+this.Id+
	"\n\n Nombre :"+this.Nombre+
	"\n\n Cantidad Stock :"+this.cantStock+
	"\n\n Precio :"+this.Precio+
	"\n\n Valor Inventario :"+this.getValorInventario()+
	"\n\n Estado :"+(this.Estado? "Activo":"No activo");
	//"\n\n Estado :"+this.Estado;
	}

}
