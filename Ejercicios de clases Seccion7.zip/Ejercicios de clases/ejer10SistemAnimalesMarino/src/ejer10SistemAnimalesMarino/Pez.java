package ejer10SistemAnimalesMarino;

public class Pez extends AnimalMarino {
	public void nadar() {
		System.out.println("El Pez Lapiz está muy gordo");
	}
}
