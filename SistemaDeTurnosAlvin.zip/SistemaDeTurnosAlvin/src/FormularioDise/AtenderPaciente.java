package FormularioDise;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import java.awt.CardLayout;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.Cursor;

public class AtenderPaciente extends JFrame implements MouseListener, MouseMotionListener {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JPanel panelMover;
	int xMouse, yMouse;
	private JLabel lblCerrar;
	private JPanel btnExit;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AtenderPaciente frame = new AtenderPaciente();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AtenderPaciente() {
		setUndecorated(true);
		setLocationByPlatform(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 513, 610);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(16, 182, 165));
		panel.setBounds(0, 0, 514, 610);
		contentPane.add(panel);
		
		JPanel btnAtender = new JPanel();
		btnAtender.setLayout(null);
		btnAtender.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(255, 255, 0)));
		btnAtender.setBackground(new Color(2, 166, 71));
		btnAtender.setBounds(155, 556, 191, 36);
		panel.add(btnAtender);
		
		JLabel lblAtender = new JLabel("ATENDER");
		lblAtender.setHorizontalAlignment(SwingConstants.CENTER);
		lblAtender.setForeground(Color.WHITE);
		lblAtender.setFont(new Font("Roboto Black", Font.BOLD, 15));
		lblAtender.setBounds(0, 0, 191, 36);
		btnAtender.add(lblAtender);
		
		JPanel panelTabla = new JPanel();
		panelTabla.setBounds(20, 88, 472, 457);
		panel.add(panelTabla);
		panelTabla.setLayout(null);
		
		JPanel panelAtencionPacientes = new JPanel();
		panelAtencionPacientes.setBounds(30, 10, 411, 86);
		panelTabla.add(panelAtencionPacientes);
		panelAtencionPacientes.setBackground(Color.LIGHT_GRAY);
		panelAtencionPacientes.setLayout(null);
		
		JLabel lblSeleccionarConsultorio = new JLabel("SELECCIONAR CONSULTORIO");
		lblSeleccionarConsultorio.setBounds(10, 11, 214, 24);
		panelAtencionPacientes.add(lblSeleccionarConsultorio);
		lblSeleccionarConsultorio.setFont(new Font("Roboto", Font.BOLD, 15));
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(218, 11, 183, 24);
		panelAtencionPacientes.add(comboBox);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(258, 46, 143, 24);
		panelAtencionPacientes.add(comboBox_1);
		
		JLabel lblNewLabel_1 = new JLabel("SELECCIONAR DIA");
		lblNewLabel_1.setBounds(119, 45, 143, 24);
		panelAtencionPacientes.add(lblNewLabel_1);
		lblNewLabel_1.setFont(new Font("Roboto", Font.BOLD, 15));
		
		JLabel lblNewLabel_2_1 = new JLabel("RED");
		lblNewLabel_2_1.setBounds(10, 46, 39, 24);
		lblNewLabel_2_1.setFont(new Font("Roboto", Font.BOLD, 15));
		panelAtencionPacientes.add(lblNewLabel_2_1);
		
		textField = new JTextField();
		textField.setBounds(46, 47, 52, 24);
		textField.setColumns(10);
		panelAtencionPacientes.add(textField);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(128, 255, 255));
		panel_1.setBounds(10, 106, 452, 341);
		panelTabla.add(panel_1);
		
		JLabel lblAtenderPacientes = new JLabel("ATENDER PACIENTES");
		lblAtenderPacientes.setHorizontalAlignment(SwingConstants.CENTER);
		lblAtenderPacientes.setFont(new Font("Franklin Gothic Heavy", Font.BOLD, 45));
		lblAtenderPacientes.setBackground(UIManager.getColor("Button.background"));
		lblAtenderPacientes.setBounds(0, 35, 511, 63);
		panel.add(lblAtenderPacientes);
		
		panelMover = new JPanel();
		panelMover.addMouseMotionListener(this);
		panelMover.addMouseListener(this);
		panelMover.setLayout(null);
		panelMover.setBackground(new Color(16, 182, 165));
		panelMover.setBounds(0, 0, 511, 36);
		panel.add(panelMover);
		
		btnExit = new JPanel();
		btnExit.addMouseListener(this);
		btnExit.setLayout(null);
		btnExit.setBackground(new Color(222, 222, 222));
		btnExit.setBounds(0, 0, 40, 37);
		panelMover.add(btnExit);
		
		lblCerrar = new JLabel("X");
		lblCerrar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblCerrar.addMouseListener(this);
		lblCerrar.setHorizontalAlignment(SwingConstants.CENTER);
		lblCerrar.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblCerrar.setBackground(new Color(222, 222, 222));
		lblCerrar.setBounds(0, 0, 40, 37);
		btnExit.add(lblCerrar);
	}
	public void mouseClicked(MouseEvent e) {
		if (e.getSource() == lblCerrar) {
			handleLblCerrarMouseClicked(e);
		}
	}
	public void mouseEntered(MouseEvent e) {
		if (e.getSource() == lblCerrar) {
			handleBtnExitMouseEntered(e);
		}
	}
	public void mouseExited(MouseEvent e) {
		if (e.getSource() == lblCerrar) {
			handleLblCerrarMosueExited(e);
		}
	}
	public void mousePressed(MouseEvent e) {
		if (e.getSource() == panelMover) {
			handlePanelMoverMousePressed(e);
		}
	}
	public void mouseReleased(MouseEvent e) {
	}
	protected void handlePanelMoverMousePressed(MouseEvent evt) {
		xMouse = evt.getX();
		yMouse = evt.getY();
	}
	public void mouseDragged(MouseEvent e) {
		if (e.getSource() == panelMover) {
			handlePanelMoverMouseDragged(e);
		}
	}
	public void mouseMoved(MouseEvent e) {
	}
	protected void handlePanelMoverMouseDragged(MouseEvent evt) {
		int x = evt.getXOnScreen();
		int y = evt.getYOnScreen();
		this.setLocation(x- xMouse, y- yMouse);
	}
	protected void handleLblCerrarMouseClicked(MouseEvent e) {
		Menu menu = new Menu();
		menu.setVisible(true);
		this.setVisible(false);
	}
	protected void handleBtnExitMouseEntered(MouseEvent e) {
		btnExit.setBackground(Color.red);
	}
	protected void handleLblCerrarMosueExited(MouseEvent e) {
		//color cuando sales mouse encima la etiqueta CERRAR SESION
		Color c = new Color(222,222,222);
		btnExit.setBackground(c);
	}
}
