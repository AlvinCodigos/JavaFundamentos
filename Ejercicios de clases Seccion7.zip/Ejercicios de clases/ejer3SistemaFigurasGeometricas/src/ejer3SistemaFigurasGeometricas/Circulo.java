package ejer3SistemaFigurasGeometricas;

public class Circulo extends Figura{

    double radio =2.5;
    double total ;
    @Override
    public double calcularArea() {
    	total = Math.PI * Math.pow(radio, 2);
    	 System.out.println(total);
    	 return total;

    }

}
