package ejer7SistemaDeTransport;

public class Transporte {
	int Capacidad;
	double Velocidad;
	public Transporte(int capacidad,double velocidad){
		this.Capacidad=capacidad;
		this.Velocidad=velocidad;
	}
	public void mover() {
		
	}
}
