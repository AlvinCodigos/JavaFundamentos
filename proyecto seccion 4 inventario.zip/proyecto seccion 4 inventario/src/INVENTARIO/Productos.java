package INVENTARIO;

public class Productos {
	private int Id;
	private String Nombre;
	private int cantStock;
	private double Precio;
	
	public Productos(){
	}
	public Productos(int Id, String Nombre,int cantStock, double Precio){
	this.Id= Id;
	this.Nombre= Nombre;
	this.cantStock= cantStock;
	this.Precio= Precio;
	}
	public int getId(){
	return Id;
	}
	public void setId(int Id){
	this.Id = Id;
	}
	public String getNombre(String Nombre){
	return Nombre;
	}
	public void setNombre(String Nombre){
	this.Nombre = Nombre;
	}
	public int getCantStock(int CantStock){
	return CantStock;
	}
	public void setCantStock (int CantStock){
	this.cantStock = CantStock;
	}
	public double getPrecio(double Precio){
	return Precio;
	}
	public void setPrecio (double Precio){
	this.Precio = Precio;
	}
	public String toString(){
	return "\n\n Numero de ID :"+this.Id+
	"\n\n Nombre :"+this.Nombre+
	"\n\n Cantidad Stock :"+this.cantStock+
	"\n\n precio :"+this.Precio;
	}


}
