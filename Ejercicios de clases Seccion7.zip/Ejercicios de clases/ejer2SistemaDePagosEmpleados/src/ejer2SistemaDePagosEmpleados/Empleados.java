package ejer2SistemaDePagosEmpleados;

public class Empleados {
	protected String nombre;
    protected double salario;


    public Empleados(String nombre, double salario) {
        this.nombre = nombre;
        this.salario = salario;
    }

    public double calcularPago() {
        return salario;
    }
}
