package ejer5SistemDeDispositivosElectronicos;

public class Radio extends Encendible {
	@Override
	public void encender() {
		System.out.println("La radio está encendida papu");
	}

}
