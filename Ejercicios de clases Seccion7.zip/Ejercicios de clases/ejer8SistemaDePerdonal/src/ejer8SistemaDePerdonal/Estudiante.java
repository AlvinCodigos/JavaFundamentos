package ejer8SistemaDePerdonal;

public class Estudiante extends Persona{

	public void Trabajar() {
		System.out.println("El Estudiante Alvin es un crack");
	}
}
