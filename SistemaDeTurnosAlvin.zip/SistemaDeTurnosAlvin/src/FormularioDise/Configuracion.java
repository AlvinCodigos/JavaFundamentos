package FormularioDise;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.awt.Cursor;

public class Configuracion extends JFrame implements MouseListener, MouseMotionListener {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JPanel panelMover;
	int xMouse, yMouse;
	private JLabel lblCerrar;
	private JPanel btnExit;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Configuracion frame = new Configuracion();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Configuracion() {
		setLocationByPlatform(true);
		setResizable(false);
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 498, 655);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(16, 182, 165));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		panelMover = new JPanel();
		panelMover.addMouseMotionListener(this);
		panelMover.addMouseListener(this);
		panelMover.setLayout(null);
		panelMover.setBackground(new Color(16, 182, 165));
		panelMover.setBounds(0, 0, 498, 36);
		contentPane.add(panelMover);
		
		btnExit = new JPanel();
		btnExit.addMouseListener(this);
		btnExit.setLayout(null);
		btnExit.setBackground(new Color(222, 222, 222));
		btnExit.setBounds(0, 0, 40, 37);
		panelMover.add(btnExit);
		
		lblCerrar = new JLabel("X");
		lblCerrar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblCerrar.addMouseListener(this);
		lblCerrar.setHorizontalAlignment(SwingConstants.CENTER);
		lblCerrar.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblCerrar.setBackground(new Color(222, 222, 222));
		lblCerrar.setBounds(0, 0, 40, 37);
		btnExit.add(lblCerrar);
	}

	public void mouseClicked(MouseEvent e) {
		if (e.getSource() == lblCerrar) {
			handleLblCerrarMouseClicked(e);
		}
	}
	public void mouseEntered(MouseEvent e) {
		if (e.getSource() == lblCerrar) {
			handleBtnExitMouseEntered(e);
		}
	}
	public void mouseExited(MouseEvent e) {
		if (e.getSource() == lblCerrar) {
			handleLblCerrarMosueExited(e);
		}
	}
	public void mousePressed(MouseEvent e) {
		if (e.getSource() == panelMover) {
			handlePanelMoverMousePressed(e);
		}
	}
	public void mouseReleased(MouseEvent e) {
	}
	protected void handlePanelMoverMousePressed(MouseEvent evt) {
		xMouse = evt.getX();
		yMouse = evt.getY();
	}
	public void mouseDragged(MouseEvent e) {
		if (e.getSource() == panelMover) {
			handlePanelMoverMouseMoved(e);
		}
	}
	public void mouseMoved(MouseEvent e) {

	}
	protected void handlePanelMoverMouseMoved(MouseEvent evt) {
		int x = evt.getXOnScreen();
		int y = evt.getYOnScreen();
		this.setLocation(x- xMouse, y- yMouse);
	}
	protected void handleLblCerrarMouseClicked(MouseEvent e) {
		Menu menu = new Menu();
		menu.setVisible(true);
		this.setVisible(false);
	}
	protected void handleBtnExitMouseEntered(MouseEvent e) {
		btnExit.setBackground(Color.red);
	}
	protected void handleLblCerrarMosueExited(MouseEvent e) {
		//color cuando sales mouse encima la etiqueta CERRAR SESION
		Color c = new Color(222,222,222);
		btnExit.setBackground(c);
	}
}
