package Operaciones;

public class Pacientes {
	private int numero;
    private String nombrePaciente;
    private String consultorio;
    private String dia;
    private String hora;
    private String fecha;
    private String codigoFicha;
    private String estado;

    public Pacientes(int numero, String nombrePaciente, String consultorio, String dia, String hora, String fecha, String codigoFicha, String estado) {
        this.numero = numero;
        this.nombrePaciente = nombrePaciente;
        this.consultorio = consultorio;
        this.dia = dia;
        this.hora = hora;
        this.fecha = fecha;
        this.codigoFicha = codigoFicha;
        this.estado = estado;
    }

    public int getNumero() {
        return numero;
    }

    public String getNombrePaciente() {
        return nombrePaciente;
    }

    public String getConsultorio() {
        return consultorio;
    }

    public String getDia() {
        return dia;
    }

    public String getHora() {
        return hora;
    }

    public String getFecha() {
        return fecha;
    }

    public String getCodigoFicha() {
        return codigoFicha;
    }

    public String getEstado() {
        return estado;
    }
}
