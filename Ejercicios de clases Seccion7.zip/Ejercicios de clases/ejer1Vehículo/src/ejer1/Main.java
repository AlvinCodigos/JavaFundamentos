package ejer1;

public class Main {

	public static void main(String[] args) {
		Coche Coche = new Coche("TORINO", "1970");
        Moto Moto = new Moto("TEKKEN", "2024");
        

        System.out.println("Coche:");
        System.out.println("Marca:"+Coche.Marca);
        System.out.println("Modelo:"+Coche.Modelo);
        Coche.Acelerar();
        
        System.out.println("--------------------------------------");
        System.out.println("Moto:");
        System.out.println("Marca:"+Moto.Marca);
        System.out.println("Modelo:"+Moto.Modelo);
        Moto.Acelerar();
	}
}
