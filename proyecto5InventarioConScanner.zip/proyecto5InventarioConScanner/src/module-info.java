/**
 * 
 */
/**
 * 
 */
module proyecto5InventarioConScanner {
}