package ejer9SistemaDeProductos;

import java.util.ArrayList;
import java.util.List;

public class Main {
	public static void main(String[] args) {
		List<Vendible> venta= new ArrayList<>();
		venta.add(new Producto("Laptop HP",3800));
		venta.add(new Producto("Impresora Canon",2500));
		System.out.println("---------------------------------------------------------------");
		venta.add(new Servicio("Cambio de bateria",420));
		venta.add(new Servicio("Cambio Sistema Operativo",80));
		
		for (Vendible ventas : venta) {
			ventas.Vender();
		}
		}

}
