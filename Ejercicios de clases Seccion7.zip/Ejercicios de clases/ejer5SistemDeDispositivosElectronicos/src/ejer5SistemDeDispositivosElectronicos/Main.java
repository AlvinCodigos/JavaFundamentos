package ejer5SistemDeDispositivosElectronicos;

import java.util.ArrayList;
import java.util.List;

public class Main {
	public static void main(String[] args) {
		List<Encendible> dispositivos = new  ArrayList<>();
		dispositivos.add(new Radio());
		dispositivos.add(new Television());
		
		for (Encendible encendible : dispositivos) {
			encendible.encender();
		}
	}
}
