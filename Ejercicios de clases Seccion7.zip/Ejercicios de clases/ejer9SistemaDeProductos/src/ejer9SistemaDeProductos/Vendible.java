package ejer9SistemaDeProductos;

public class Vendible {
	public void Vender() {
		
	}
}
