package ejer6SistemaDeBiblioteca;



public class Main {
	public static void main(String[] args) {
		
		System.out.println("-------------------------");
		Publicacion Biblio = new Libro("Fabulas de ESOPO","Jaimito Ortiz");
		System.out.println("Titulo: "+Biblio.titulo);
		System.out.println("Autor: "+Biblio.autor);
		Biblio.MostrarInformacion();
		System.out.println("-------------------------");
		Publicacion msotrar = new Revista("Estilo de Flow ","Mariano Lopez");
		System.out.println("Titulo: "+msotrar.titulo);
		System.out.println("Autor: "+msotrar.autor);
		msotrar.MostrarInformacion();
	}
	
}
