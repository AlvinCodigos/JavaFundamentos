package ejer3SistemaFigurasGeometricas;

public abstract class Figura {
	public abstract  double calcularArea();
}
