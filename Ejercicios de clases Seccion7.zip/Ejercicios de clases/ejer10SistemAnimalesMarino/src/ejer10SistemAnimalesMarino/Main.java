package ejer10SistemAnimalesMarino;

import java.util.ArrayList;
import java.util.List;

public class Main {
	public static void main(String[] args) {
		List<AnimalMarino> aminales = new  ArrayList<>();
		aminales.add(new Pez());
		aminales.add(new Tiburon());
		aminales.add(new Delfin());
		
		for (AnimalMarino animal : aminales) {
			animal.nadar();
		}
	}	
}
