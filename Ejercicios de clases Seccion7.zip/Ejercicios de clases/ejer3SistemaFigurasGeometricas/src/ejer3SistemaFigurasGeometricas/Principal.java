package ejer3SistemaFigurasGeometricas;



public class Principal {

	public static void main(String[] args) {
		//Circulo  circulo= new Circulo(2.5);
		//Rectangulo rectangulo= new Rectangulo(3,5);
		System.out.print("El Area del circulo es: ");
		Figura miCirculo= new Circulo();
		miCirculo.calcularArea();
		System.out.print("El Area del rectangulo es: ");
		Figura miRectangulo= new Rectangulo();
		miRectangulo.calcularArea();
	}
}
