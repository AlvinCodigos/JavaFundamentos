package ejer4SistemasDeAnimales;

public class Animal {

	public void HacerSonido() {
		
	}
}
