package ejer6SistemaDeBiblioteca;

public class Revista extends Publicacion{

	public Revista(String titulo, String autor) {
		super(titulo, autor);
		// TODO Auto-generated constructor stub
	}
	public void MostrarInformacion() {
		
		System.out.println("La revista es de modelaje.");
		return;
	}

}
